package com.library.factoryinterface;

public interface searchInterface {
	
	void search(String catagory);
}
